package cinemaArrange;

import java.io.Serializable;

public class Seat implements Serializable{
	
	
	/**
	 * 座椅位置，由两个字符组成，第一个字符是字母，代表行数，第二个字符是数字，代表列数
	 */
	public String position;
	/**
	 * 座椅是否可用
	 */
	public boolean avaliable=true;

	
	/**
	 * 
	 * @param a 所在行
	 * @param b 所在列
	 * @see Screen#Screen(int[][], String)
	 */
	public Seat(int a,int b) {
		this.position=(char)(a+64)+""+b;
	}
}
