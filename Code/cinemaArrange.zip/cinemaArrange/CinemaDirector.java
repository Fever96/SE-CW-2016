package cinemaArrange;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

import ticket.Ticket;
/**
 * 包括所有日期的安排、影院影厅结构以及影院中所有的影片
 * 整个程序中有且仅有一个该类的实例
 * @author 
 * @see cinemaArrange.Screen
 * @see cinemaArrange.Arrange
 * @see cinemaArrange.Movie
 */
public class CinemaDirector implements Serializable{

	
	/**独一无二的静态影院管理者单件 */
	private static CinemaDirector myCinemaDirector;
	/**影院中所有影厅的作为排布 */
	public ArrayList<Screen> allScreen=new ArrayList<Screen>();
	/**影院所有日期的安排 */
	public ArrayList<Arrange> difDayArran=new ArrayList<Arrange>();
	/**影院中所有的影片 */
	public ArrayList<Movie> allMovies=new ArrayList<Movie>();
	
	/**
	 * 单件的私有构造函数
	 */
	private CinemaDirector(){
		
	}
	/**
	 * 外界调取影院管理者单件的入口
	 * @return 独一无二的影院管理者单件
	 */
	public static CinemaDirector getUniqueDirector(){
		if(myCinemaDirector==null){
			myCinemaDirector=new CinemaDirector();
		}
		return myCinemaDirector;
	}
	/**
	 * 设置一个独一无二的影院管理者单件（而不是新建）
	 * @param cd 影院管理者单件
	 * @see CinemaIO#readAllArrange()
	 */
	public static void setUniqueDirector(CinemaDirector cd){
		myCinemaDirector=cd;
	}
	/**
	 * 克隆一个新的影厅，其中所有座位都处于可用状态，且不与此类中存储的影厅指向同一个对象
	 * @param index 希望获得的影厅编号 从0开始
	 * @return 希望获得到的影厅
	 * @see cinemaArrange.Screen
	 * @see cinemaArrange.Seat
	 */
	public Screen getTheScreen(int index){
		Screen myScreen=allScreen.get(index);
		Screen yourScreen=new Screen(myScreen.layout,myScreen.id);//克隆新的screen
		return yourScreen;
	}
	/**
	 * 获取特定日期的安排
	 * @param index 希望获得的一日安排的编号，第一天是0，第二天是1，以此类推
	 * @return 特定日期的安排
	 */
	public Arrange getArrange(int index){
		return difDayArran.get(index);
	}
	/**
	 * 模拟进入下一天
	 */
	public void NextDay(){
		CinemaIO.printReport();
		Arrange a=difDayArran.get(0);
		a.ticketToday.clear();
		a.movieToday.clear();
		a.showToday.clear();
		difDayArran.remove(a);
		difDayArran.add(a);
		for(Arrange ar:this.difDayArran){
			for(Show show:ar.showToday){
				show.date--;
			}
		}
		CinemaIO.storeAllArrange();
	}
/**
 * 取消一张已经购买的票
 * @param tNum 想要取消的票的编号
 * @return 真：取消成功 假：取消失败
 */
	public boolean cancel(String tNum) {
		Ticket cancelT=null;
		for(Arrange arr:this.difDayArran){
			for(Ticket t:arr.ticketToday){
				if(t.ID.equals(tNum)){
					cancelT=t;
				}
			}
			if(cancelT!=null){
				arr.cancelTicket(cancelT);
				String fileName="Ticket_"+cancelT.ID+".txt";
		        File file =new File(fileName);
		        if(file.exists()){
		        	file.delete();
		        }
		        CinemaIO.storeAllArrange();
				return true;
			}
		}
		return false;
	}
	
}
