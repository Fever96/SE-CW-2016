package cinemaArrange;

import java.awt.Image;
import java.io.File;
import java.io.Serializable;

import javax.swing.ImageIcon;
/**
 * 影片类
 * @author 
 *
 */
public class Movie implements Serializable {
	/**
	 * 影片名
	 */
	public String name;
	/**
	 * 影片信息
	 */
	public String info="sahsgdcysdghjsgcjgvasdcgfsjcvsdjhcvsydcvsdhjvcsdhjcvsdhjcvsjdhcvjsdhvcjhdsvcjsdhcvsdjhcvdsjhcvdsjhcvsjhcvsjhdcvsdjhcvsjhdcvsjhcvsjhcvsjhcvsjhcvsdjcvdbcvsdugfsvnbsdjkfbiuerhfgsdkjvbkushgkuewnvsdkjvbiusgfivwehbvckjsdbcviuegfuiewbscvkjadsbcfuegukesbfkjsdgfugdasdasd";
	/**
	 * 影片时长
	 */
	public int timeUsed=100;
	/**
	 * 影片封面
	 */
	public ImageIcon img;
	/**
	 * 高品质影片封面
	 */
	public ImageIcon betterImg;
	
	/**
	 * 
	 * @param s 影片名
	 */
	public Movie(String s){
		this.name=s;
		ImageIcon imge = new ImageIcon("default.jpg");  
		Image image=imge.getImage();
		Image scaledImage=image. getScaledInstance(100,150, Image.SCALE_DEFAULT);
		this.img=new ImageIcon(scaledImage);
		scaledImage=image. getScaledInstance(300,450, Image.SCALE_DEFAULT);
		this.betterImg=new ImageIcon(scaledImage);
	}

	/**
	 * 设置封面
	 * @param string 图片文件的路径
	 */
	public void setImg(String string) {
		ImageIcon imge = new ImageIcon(string);
		Image image=imge.getImage();
		Image scaledImage=image. getScaledInstance(100,150, Image.SCALE_DEFAULT);
		this.img=new ImageIcon(scaledImage);
		scaledImage=image. getScaledInstance(300,450, Image.SCALE_DEFAULT);
		this.betterImg=new ImageIcon(scaledImage);
		
	}

}
