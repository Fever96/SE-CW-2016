package cinemaArrange;

import java.io.Serializable;
/**
 * 一场电影的时间、地点、内容
 * @author 
 *
 */
public class Show implements Serializable{

	/**
	 * 日期
	 */
	public int date;
	/**
	 * 开场时间-分
	 */
	public int minute;
	/**
	 * 开场时间-时
	 */
	public int hour;
	/**
	 * 上映影厅
	 */
	public Screen screen;
	/**
	 * 上映电影
	 */
	public Movie movie;
	/**
	 * 
	 * @param m 电影
	 * @param s 影厅
	 * @param h 几点开始
	 * @param min 几分开始
	 * @param date 哪一天
	 */
	public Show(Movie m,Screen s ,int h,int min,int date){
		this.movie=m;
		this.screen=s;
		this.hour=h;
		this.minute=min;
		this.date=date;
		
	}
	
}
