package cinemaArrange;

import java.io.Serializable;
import java.util.ArrayList;
/**
 * 
 * @author 
 *
 */
public class Screen implements Serializable{
	/**
	 * 行数
	 */
	public int row;
	/**
	 * 列数
	 */
	public int cal;
	/**
	 * 用于表示影厅结构的矩阵，1是有座位，0是无座位
	 */
	public int[][] layout;
	/**
	 * 影厅编号
	 */
	public String id;
	/**
	 * 影厅中的座位
	 */
	public ArrayList<Seat> seatList=new ArrayList<Seat>();
	/**
	 * 
	 * @param layout 影厅结构矩阵,将根据此矩阵自动生成座椅对象
	 * @param str 影厅编号
	 */
	public Screen(int[][] layout,String str){
		this.layout=layout;
		this.id=str;
		this.row=layout.length;
		this.cal=layout[0].length;
		for(int i=0;i<this.row;i++){
			int k=0;
			for(int j=0;j<this.cal;j++){
				if(layout[i][j]==1){
					k++;
					Seat s = new Seat(i+1,k);
					seatList.add(s);
					}
				
			}
		}
		
		
		
	}
	
	

}
