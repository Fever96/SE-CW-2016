package cinemaArrange;

import java.io.Serializable;
import java.util.ArrayList;

import ticket.Ticket;
/**
 * 此类包含影院一天内所有的安排与业务，包括当天上映的影片，上映安排，售出的票
 * @author 
 *
 */
public class Arrange implements Serializable{
	/**当天上映的所有电影*/
	public ArrayList<Movie> movieToday=new ArrayList<Movie>();
	/**当天的所有上映安排*/
	public ArrayList<Show> showToday=new ArrayList<Show>();
	/**当天售出的所有票*/
	public ArrayList<Ticket> ticketToday=new ArrayList<Ticket>();
	
	/**
	 * 新增一个票
	 * @param t 新增的票
	 */
	public void addTicket(Ticket t){
		this.ticketToday.add(t);
	}

	/**
	 * 取消一个票
	 * @param cancelT 将要被取消的票
	 */
	public void cancelTicket(Ticket cancelT) {
		System.out.println(this.ticketToday.size());
		this.ticketToday.remove(cancelT);
		System.out.println(this.ticketToday.size());
		
	}	
	

}
